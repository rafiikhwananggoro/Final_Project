﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUBBLESPARTICLES
{
    internal class Bubbles
    {
        public int height;
        public int widht;
        public int PosX;
        public int posY;
        public int[] size = { 10, 20, 30, 40, 50, 60, };
        public int speedXt = 1;
        public int speedY;
        public int toplimit;
        public int moveLimit;

        public Image bubble;
        Random random = new Random();

        public Bubbles()
        {
            moveLimit = random.Next(50,200 );
            int i = random.Next (0, size.Length);
            bubble = Image.FromFile("image/bubbles.png");

            height = size[i];
            widht = size[i];

            toplimit = random.Next(10,100);
            PosX = random.Next(-10, 800);
            posY = random.Next(600, 1200);

            speedY = random.Next(1, 5);
        }

        public void MoveBubble()
        {
            moveLimit -= 1;
            if (moveLimit < 1) 
            {
                speedXt = -speedXt;
                moveLimit = random.Next(50,200);
            }
        }
    }
}
